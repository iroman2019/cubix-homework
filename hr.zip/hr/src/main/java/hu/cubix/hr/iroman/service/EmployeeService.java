package hu.cubix.hr.iroman.service;

import hu.cubix.hr.iroman.model.Employee;

public interface EmployeeService {

	public int getPayRaisetPercent(Employee employee);

}
